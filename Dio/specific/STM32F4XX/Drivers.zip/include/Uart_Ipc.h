/***********************************************************************************************************************
 * Project Name: HuLa STM
 * 
 * File Name: Uart_Ipc.h
 *
 * Description: Implementation of Uart_Ipc IPC Level layer
 *              
 * AutoSAR Version:         4.4.0
 *
 * Compiler: GCC IAR
 *
 * Revision:
 *              Version         Date                Change History
 *              0.9.0          07/04/2024           Initial version
 *
 **********************************************************************************************************************/

#ifndef UART_IPC_H
#define UART_IPC_H

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************************************************************************
 *                                                     INCLUDES 
 **********************************************************************************************************************/

#include "Uart_Ip.h"
#include "Uart_Ipc_Cfg.h"

/***********************************************************************************************************************
 *                                                 SOURCE FILE VERSION
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                 FILE VERSION CHECK
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                   LOCAL MACROS
 **********************************************************************************************************************/

#define START_CONFIG_DATA_UNSPECIFIED
#include "MemMap.h"
/**
 * @brief   Export IPC configurations.
 */
UART_IPC_CONFIG_EXT
#define STOP_CONFIG_DATA_UNSPECIFIED
#include "MemMap.h"

/***********************************************************************************************************************
 *                                       LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                      EXTERN
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                  LOCAL CONSTANTS
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                  LOCAL VARIABLES
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                 GLOBAL VARIABLES
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                             LOCAL FUNCTION PROTOTYPES
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                  LOCAL FUNCTION
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                  GLOBAL FUNCTION
 **********************************************************************************************************************/

#define START_CODE
#include "MemMap.h"

/**
 *  @brief          Initializes the Uart Driver module.
 *
 *  @details
 *                  Service ID:        N/A
 *                  SRS ID:            N/A
 *                  Design ID:         Uart_Ipc_Init_Activity
 *                  Sync/Async:        Synchronous
 *                  Reentrancy:        Non Reentrant
 *
 *  @arg            Uart_Ipc_ConfigType *  
 *  @param[in]      para_UartIpcConfig_ptr         Pointer to configuration structure.
 *
 *  @return         void     
 *  @retval         None    
 *
 *  @note           None
 *
 *  @pre            None
 *
 *  @post           None
 *
 **/
void Uart_Ipc_Init
(
    Uart_Ipc_ConfigType *para_UartIpcConfig_ptr
);

/**
 *  @brief          This function sets config Uart.
 *
 *  @details
 *                  Service ID:        N/A
 *                  SRS ID:            N/A
 *                  Design ID:         Uart_Ipc_SetConfig_Activity
 *                  Sync/Async:        Synchronous
 *                  Reentrancy:        Reentrant
 *
 *  @arg            const Uart_Ipc_EachConfigType *
 *  @param[in]      para_UartConfig_ptr            Config structure to be set.
 *
 *  @return         None     
 *  @retval         None
 *
 *  @note           None
 *
 *  @pre            None
 *
 *  @post           None
 *
 **/
void Uart_Ipc_SetConfig
(
    const Uart_Ipc_EachConfigType *para_UartConfig_ptr
);

/**
 *  @brief          This function to Async Send.
 *
 *  @details
 *                  Service ID:        N/A
 *                  SRS ID:            N/A
 *                  Design ID:         Uart_Ipc_AsyncSend_Activity
 *                  Sync/Async:        Synchronous
 *                  Reentrancy:        Reentrant
 *
 *  @arg            const Uart_Ipc_EachConfigType*
 *  @param[in]      para_UartConfig_ptr              Pointer to config set.
 *  @arg            uint8*
 *  @param[in]      para_Buffer_ptr                  Pointer to Buffer.
 *  @arg            uint32
 *  @param[in]      para_BufferSize_u32              Size of Bufer.
 *
 *  @return         None     
 *  @retval         None
 *
 *  @note           None
 *
 *  @pre            None
 *
 *  @post           None
 *
 **/
Std_ReturnType Uart_Ipc_AsyncSend
(
    const Uart_Ipc_EachConfigType *para_UartConfig_ptr,
    uint8* para_Buffer_ptr,
    uint32 para_BufferSize_u32
);

/**
 *  @brief          This function to Async Receive.
 *
 *  @details
 *                  Service ID:        N/A
 *                  SRS ID:            N/A
 *                  Design ID:         Uart_Ipc_AsyncReceive_Activity
 *                  Sync/Async:        Synchronous
 *                  Reentrancy:        Reentrant
 *
 *  @arg            const Uart_Ipc_EachConfigType*
 *  @param[in]      para_UartConfig_ptr              Pointer to config set.
 *  @arg            uint8*
 *  @param[in]      para_Buffer_ptr                  Pointer to Buffer.
 *  @arg            uint32
 *  @param[in]      para_BufferSize_u32              Size of Bufer.
 *
 *  @return         None     
 *  @retval         None
 *
 *  @note           None
 *
 *  @pre            None
 *
 *  @post           None
 *
 **/
Std_ReturnType Uart_Ipc_AsyncReceive
(
    const Uart_Ipc_EachConfigType *para_UartConfig_ptr,
    uint8* para_Buffer_ptr,
    uint32 para_BufferSize_u32
);


/**
 *  @brief          This function to Sync Send.
 *
 *  @details
 *                  Service ID:        N/A
 *                  SRS ID:            N/A
 *                  Design ID:         Uart_Ipc_SyncSend_Activity
 *                  Sync/Async:        Synchronous
 *                  Reentrancy:        Reentrant
 *
 *  @arg            const Uart_Ipc_EachConfigType*
 *  @param[in]      para_UartConfig_ptr              Pointer to config set.
 *  @arg            uint8*
 *  @param[in]      para_Buffer_ptr                  Pointer to Buffer.
 *  @arg            uint32
 *  @param[in]      para_BufferSize_u32              Size of Bufer.
 *
 *  @return         None     
 *  @retval         None
 *
 *  @note           None
 *
 *  @pre            None
 *
 *  @post           None
 *
 **/
Std_ReturnType Uart_Ipc_SyncSend
(
    const Uart_Ipc_EachConfigType *para_UartConfig_ptr,
    uint8* para_Buffer_ptr,
    uint32 para_BufferSize_u32
);


/**
 *  @brief          This function to Sync Receive.
 *
 *  @details
 *                  Service ID:        N/A
 *                  SRS ID:            N/A
 *                  Design ID:         Uart_Ipc_SyncReceive_Activity
 *                  Sync/Async:        Synchronous
 *                  Reentrancy:        Reentrant
 *
 *  @arg            const Uart_Ipc_EachConfigType*
 *  @param[in]      para_UartConfig_ptr              Pointer to config set.
 *  @arg            uint8*
 *  @param[in]      para_Buffer_ptr                  Pointer to Buffer.
 *  @arg            uint32
 *  @param[in]      para_BufferSize_u32              Size of Bufer.
 *
 *  @return         None     
 *  @retval         None
 *
 *  @note           None
 *
 *  @pre            None
 *
 *  @post           None
 *
 **/
Std_ReturnType Uart_Ipc_SyncReceive
(
    const Uart_Ipc_EachConfigType *para_UartConfig_ptr,
    uint8* para_Buffer_ptr,
    uint32 para_BufferSize_u32
);

/**
 *  @brief          This function to Change Baudrate.
 *
 *  @details
 *                  Service ID:        N/A
 *                  SRS ID:            N/A
 *                  Design ID:         Uart_Ipc_ChangeBaudrate_Activity
 *                  Sync/Async:        Synchronous
 *                  Reentrancy:        Reentrant
 *
 *  @arg            const Uart_Ipc_EachConfigType*
 *  @param[in]      para_UartConfig_ptr              Pointer to config set.
 *  @arg            Uart_Ipc_BaudrateType
 *  @param[in]      para_Baudrate_e                  New baudrate.
 *
 *  @return         None     
 *  @retval         None
 *
 *  @note           None
 *
 *  @pre            None
 *
 *  @post           None
 *
 **/
Std_ReturnType Uart_Ipc_ChangeBaudrate
(
    const Uart_Ipc_EachConfigType *para_UartConfig_ptr,
    Uart_Ipc_BaudrateType para_Baudrate_e
);

/**
 *  @brief          This function to Abort.
 *
 *  @details
 *                  Service ID:        N/A
 *                  SRS ID:            N/A
 *                  Design ID:         Uart_Ipc_Abort_Activity
 *                  Sync/Async:        Synchronous
 *                  Reentrancy:        Reentrant
 *
 *  @arg            const Uart_Ipc_EachConfigType*
 *  @param[in]      para_UartConfig_ptr              Pointer to config set.
 *
 *  @return         None     
 *  @retval         None
 *
 *  @note           None
 *
 *  @pre            None
 *
 *  @post           None
 *
 **/
Std_ReturnType Uart_Ipc_Abort
(
    const Uart_Ipc_EachConfigType *para_UartConfig_ptr
);

/**
 *  @brief          This function to DeInit.
 *
 *  @details
 *                  Service ID:        N/A
 *                  SRS ID:            N/A
 *                  Design ID:         Uart_Ipc_DeInit_Activity
 *                  Sync/Async:        Synchronous
 *                  Reentrancy:        Reentrant
 *
 *  @arg            const Uart_Ipc_EachConfigType*
 *  @param[in]      para_UartConfig_ptr              Pointer to config set.
 *
 *  @return         None     
 *  @retval         None
 *
 *  @note           None
 *
 *  @pre            None
 *
 *  @post           None
 *
 **/
Std_ReturnType Uart_Ipc_DeInit
(
    const Uart_Ipc_EachConfigType *para_UartConfig_ptr
);

#define STOP_CODE
#include "MemMap.h"

#ifdef __cplusplus
}
#endif

#endif /* UART_IPC_H */

/*--------------------------------------------------- EOF ------------------------------------------------------------*/
