/***********************************************************************************************************************
 * Project Name: HuLa STM
 * 
 * File Name: Uart_Ipc_Types.h
 *
 * Description: Implementation of Uart_Ipc_Types IP Level layer
 *              
 * AutoSAR Version:         4.4.0
 *
 * Compiler: GCC IAR
 *
 * Revision:
 *              Version         Date                Change History
 *              0.9.0          07/04/2024           Initial version
 *
 **********************************************************************************************************************/

#ifndef UART_IPC_TYPES_H
#define UART_IPC_TYPES_H

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************************************************************************
 *                                                     INCLUDES 
 **********************************************************************************************************************/

#include "Uart_Ip_Types.h"

/***********************************************************************************************************************
 *                                                 SOURCE FILE VERSION
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                 FILE VERSION CHECK
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                   LOCAL MACROS
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                       LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
 **********************************************************************************************************************/
/**
 * @brief  Uart configuration struct
 * @details Design ID: Uart_Ipc_ConfigType_Class
 */
typedef struct
{
  Uart_Ip_ConfigType (*UartIpConfig_ptr); /* Structure contain information of Uart IP config set. */
} Uart_Ipc_ConfigType;


/**
 *  @brief   Type of the Controller.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_ControllerType_Class
 */
typedef Uart_Ip_ControllerType Uart_Ipc_ControllerType;

/**
 *  @brief   Type of the Direction.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_DirectionType_Class
 */
typedef Uart_Ip_DirectionType Uart_Ipc_DirectionType;

/**
 *  @brief   Type of the Baudrate Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_BaudrateType_Class
 */
typedef Uart_Ip_BaudrateType Uart_Ipc_BaudrateType;

/**
 *  @brief   Type of the Word Length Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_WordLengthType_Class
 */
typedef Uart_Ip_WordLengthType Uart_Ipc_WordLengthType;

/**
 *  @brief   Type of the NumberOfStopBit Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_NumberOfStopBitType_Class
 */
typedef Uart_Ip_NumberOfStopBitType Uart_Ipc_NumberOfStopBitType;

/**
 *  @brief   Type of the Over Sampling Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_OverSamplingType_Class
 */
typedef Uart_Ip_OverSamplingType Uart_Ipc_OverSamplingType;

/**
 *  @brief   Type of the Transfer Method Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_TransferMethodType_Class
 */
typedef Uart_Ip_TransferMethodType Uart_Ipc_TransferMethodType;

/**
 *  @brief   Type of the ConfigSet Number Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_ConfigSetNumberType_Class
 */
typedef Uart_Ip_ConfigSetNumberType Uart_Ipc_ConfigSetNumberType;

/**
 *  @brief   Type of the CallBackID Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_CallBackIDType_Class
 */
typedef Uart_Ip_CallBackIDType Uart_Ipc_CallBackIDType;

/**
 *  @brief   Type of the Application Error Code Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_ErrorCodeType_Class
 */
typedef Uart_Ip_ErrorCodeType Uart_Ipc_ErrorCodeType;

/**
 *  @brief   Type of the State Machine Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_StateMachineType_Class
 */
typedef Uart_Ip_StateMachineType Uart_Ipc_StateMachineType;

/**
 *  @brief   Type of the One Config Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_OneConfigType_Class
 */
typedef Uart_Ip_OneConfigType Uart_Ipc_OneConfigType;

/**
 *  @brief   Type of the EachConfig Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_EachConfigType_Class
 */
typedef Uart_Ip_EachConfigType Uart_Ipc_EachConfigType;


/**
 *  @brief   Type of the State Type.
 *  @details SRS ID:     N/A
 *           Design ID:  Uart_Ipc_StateType_Class
 */
typedef Uart_Ip_StateType Uart_Ipc_StateType;



/***********************************************************************************************************************
 *                                                      EXTERN
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                  LOCAL CONSTANTS
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                  LOCAL VARIABLES
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                 GLOBAL VARIABLES
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                             LOCAL FUNCTION PROTOTYPES
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                  LOCAL FUNCTION
 **********************************************************************************************************************/

/***********************************************************************************************************************
 *                                                  GLOBAL FUNCTION
 **********************************************************************************************************************/


#ifdef __cplusplus
}
#endif

#endif /* UART_IPC_TYPES_H */

/*--------------------------------------------------- EOF -----------------------------------------------------*/